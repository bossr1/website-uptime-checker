import requests
from datetime import datetime

def check_website(url):
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            return f"✅ {url} is UP"
        else:
            return f"⚠️ {url} returned status {response.status_code}"
    except requests.exceptions.RequestException:
        return f"❌ {url} is DOWN"

def log_result(result):
    with open("uptime_log.txt", "a") as log:
        log.write(f"{datetime.now()} - {result}\n")

if __name__ == "__main__":
    sites = ["https://tvoyztr.com.ua", "https://google.com", "https://github.com"]
    for site in sites:
        result = check_website(site)
        print(result)
        log_result(result)
