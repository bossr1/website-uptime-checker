# 🌐 Website Uptime Checker

A simple Python script that checks if websites are online and logs results.

## 🚀 How to Use
1. Clone this repo:
   ```bash
   git clone https://github.com/yourusername/website-uptime-checker.git
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the script:
   ```bash
   python main.py
   ```

Results will be saved to `uptime_log.txt`.

## 🧩 Features
- Checks multiple websites
- Logs results with timestamps
- Simple and extendable

## 🛠️ Requirements
- Python 3.8+
- requests library
